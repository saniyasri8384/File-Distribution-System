import { useEffect, useState } from "react";
import api from "../services/api";
import { useNavigate } from "react-router-dom";

function SharedFiles() {

    const [sharedFiles, setSharedFiles] = useState([]);
    const [loading, setLoading] = useState(true);
    const navigate = useNavigate();

    const fetchSharedFiles = async () => {
        try {

            const token = localStorage.getItem("token");
            console.log("FETCHING SHARED FILES...");

            const response = await api.get(
                "/files/shared-with-me",
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            // Supports either "shares" or "files"
            const data =
                response.data.shares ||
                response.data.files ||
                [];

            setSharedFiles(data);

        } catch (error) {

            console.log("SHARED FILES ERROR:", error);

        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSharedFiles();
    }, []);


    const handleDownload = async (fileId, fileName) => {

        try {

            const token = localStorage.getItem("token");

            const response = await api.get(
                `/files/download/${fileId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    responseType: "blob"
                }
            );

            const url = window.URL.createObjectURL(
                new Blob([response.data])
            );

            const link = document.createElement("a");

            link.href = url;
            link.download = fileName;

            document.body.appendChild(link);

            link.click();

            link.remove();

            window.URL.revokeObjectURL(url);

        } catch (error) {

            console.log("SHARED DOWNLOAD ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Download failed"
            );
        }
    };


    if (loading) {
        return <h2>Loading shared files...</h2>;
    }


    return (
        <div>

            <h1>Shared Files</h1>

            {sharedFiles.length === 0 ? (

                <p>No files have been shared with you.</p>

            ) : (

                <table border="1" cellPadding="10">

                    <thead>
                        <tr>
                            <th>File Name</th>
                            <th>Shared By</th>
                            <th>Permission</th>
                            <th>Expiry</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                        {sharedFiles.map((share) => {

                            const file = share.file;

                            return (
                                <tr key={share._id}>

                                    <td>
                                        {file?.originalName || "Unknown file"}
                                    </td>

                                    <td>
                                        {share.sharedBy?.email ||
                                            share.sharedBy?.name ||
                                            "Unknown user"}
                                    </td>

                                    <td>
                                        {share.permission}
                                    </td>

                                    <td>
                                        {share.expiresAt
                                            ? new Date(
                                                share.expiresAt
                                            ).toLocaleString()
                                            : "No expiry"}
                                    </td>

                                    <td>

    {share.permission === "download" ? (

        <div
            style={{
                display: "flex",
                gap: "8px"
            }}
        >

            <button
                className="action-button details"
                onClick={() =>
                    navigate(`/view/${file._id}`)
                }
            >
                View
            </button>

            <button
                className="action-button download"
                onClick={() =>
                    handleDownload(
                        file._id,
                        file.originalName
                    )
                }
            >
                Download
            </button>

        </div>

    ) : (

        <button
            className="action-button details"
            onClick={() =>
                navigate(`/view/${file._id}`)
            }
        >
            View
        </button>

    )}

</td>

                                </tr>
                            );

                        })}

                    </tbody>

                </table>

            )}

        </div>
    );
}

export default SharedFiles;