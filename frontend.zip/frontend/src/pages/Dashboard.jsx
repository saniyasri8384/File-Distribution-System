import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../services/api";

function Dashboard() {

    const [statistics, setStatistics] = useState({
        totalFiles: 0,
        totalStorage: 0,
        totalDownloads: 0
    });

    const [files, setFiles] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {

        try {

            const token = localStorage.getItem("token");

            const config = {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            };

            const [statsResponse, filesResponse] =
                await Promise.all([
                    api.get("/files/statistics", config),
                    api.get("/files/my-files", config)
                ]);

            setStatistics(
                statsResponse.data.statistics || {
                    totalFiles: 0,
                    totalStorage: 0,
                    totalDownloads: 0
                }
            );

            setFiles(filesResponse.data.files || []);

        } catch (error) {

            console.log("DASHBOARD ERROR:", error);

        } finally {

            setLoading(false);
        }
    };

    const formatBytes = (bytes) => {

        if (!bytes || bytes === 0) {
            return "0 Bytes";
        }

        const units = [
            "Bytes",
            "KB",
            "MB",
            "GB"
        ];

        const index = Math.floor(
            Math.log(bytes) / Math.log(1024)
        );

        return (
            parseFloat(
                (bytes / Math.pow(1024, index)).toFixed(2)
            ) +
            " " +
            units[index]
        );
    };

    if (loading) {
        return (
            <div className="page-container">
                <h2>Loading dashboard...</h2>
            </div>
        );
    }

    return (
        <div className="page-container">

            <div className="dashboard-header">

                <div>
                    <h1>Dashboard</h1>

                    <p>
                        Manage your files and shared documents
                    </p>
                </div>

                <Link
                    to="/upload"
                    className="primary-link"
                >
                    + Upload File
                </Link>

            </div>


            {/* Statistics Cards */}

            <div className="stats-grid">

                <div className="stat-card">

                    <div className="stat-icon">
                        📁
                    </div>

                    <div>
                        <p className="stat-title">
                            Total Files
                        </p>

                        <h2>
                            {statistics.totalFiles}
                        </h2>
                    </div>

                </div>


                <div className="stat-card">

                    <div className="stat-icon">
                        💾
                    </div>

                    <div>
                        <p className="stat-title">
                            Storage Used
                        </p>

                        <h2>
                            {formatBytes(
                                statistics.totalStorage
                            )}
                        </h2>
                    </div>

                </div>


                <div className="stat-card">

                    <div className="stat-icon">
                        ⬇️
                    </div>

                    <div>
                        <p className="stat-title">
                            Total Downloads
                        </p>

                        <h2>
                            {statistics.totalDownloads}
                        </h2>
                    </div>

                </div>

            </div>

            {/* Quick Actions */}

<div className="quick-actions-section">

    <h2>Quick Actions</h2>

    <div className="quick-actions-grid">

        <Link
            to="/upload"
            className="quick-action-card"
        >
            <div className="quick-action-icon upload-icon">
                ⬆️
            </div>

            <div>
                <h3>Upload File</h3>
                <p>Add a new file to your storage</p>
            </div>
        </Link>


        <Link
            to="/my-files"
            className="quick-action-card"
        >
            <div className="quick-action-icon files-icon">
                📁
            </div>

            <div>
                <h3>My Files</h3>
                <p>View and manage your files</p>
            </div>
        </Link>


        <Link
            to="/shared-files"
            className="quick-action-card"
        >
            <div className="quick-action-icon shared-icon">
                🤝
            </div>

            <div>
                <h3>Shared Files</h3>
                <p>View files shared with you</p>
            </div>
        </Link>

    </div>

</div>


            {/* Recent Files */}

            <div className="files-section">

                <div className="section-header">

                    <h2>My Files</h2>

                    <Link to="/my-files">
                        View All
                    </Link>

                </div>


                {files.length === 0 ? (

                    <div className="empty-state">

                        <div className="empty-icon">
                            📂
                        </div>

                        <h3>
                            No files uploaded yet
                        </h3>

                        <p>
                            Upload your first file to get started.
                        </p>

                        <Link
                            to="/upload"
                            className="primary-link"
                        >
                            Upload File
                        </Link>

                    </div>

                ) : (

                    <div className="recent-files">

                        {files.slice(0, 5).map((file) => (

                            <div
                                className="file-row"
                                key={file._id}
                            >

                                <div className="file-info">

                                    <div className="file-icon">
                                        📄
                                    </div>

                                    <div>
                                        <strong>
                                            {file.originalName}
                                        </strong>

                                        <p>
                                            {formatBytes(file.size)}
                                            {" • "}
                                            {new Date(
                                                file.createdAt
                                            ).toLocaleDateString()}
                                        </p>
                                    </div>

                                </div>


                                <Link
                                    to={`/file-details/${file._id}`}
                                    className="details-link"
                                >
                                    Details
                                </Link>

                            </div>

                        ))}

                    </div>
                )}

            </div>

        </div>
    );
}

export default Dashboard;