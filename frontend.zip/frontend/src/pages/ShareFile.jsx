import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../services/api";

function ShareFile() {

    const { fileId } = useParams();
    const navigate = useNavigate();

    const [email, setEmail] = useState("");
    const [permission, setPermission] = useState("download");
    const [expiresAt, setExpiresAt] = useState("");
    const [sharing, setSharing] = useState(false);

    const handleShare = async (e) => {
        e.preventDefault();

        if (!email) {
            alert("Please enter the user's email");
            return;
        }

        try {

            setSharing(true);

            const token = localStorage.getItem("token");

            await api.post(
                "/files/share",
                {
                    fileId,
                    email,
                    permission,
                    expiresAt: expiresAt || null
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            alert("File shared successfully!");

            navigate("/my-files");

        } catch (error) {

            console.log("SHARE ERROR:", error);

            alert(
                error.response?.data?.message ||
                "File sharing failed"
            );

        } finally {
            setSharing(false);
        }
    };

    return (
        <div className="share-page">

            <div className="share-card">

                <div className="share-icon-large">
                    🤝
                </div>

                <h1>Share File</h1>

                <p className="share-subtitle">
                    Share your file securely with another user
                </p>

                <form onSubmit={handleShare}>

                    <div className="input-group">

                        <label>
                            User Email
                        </label>

                        <input
                            type="email"
                            placeholder="Enter recipient's email"
                            value={email}
                            onChange={(e) =>
                                setEmail(e.target.value)
                            }
                            required
                        />

                    </div>


                    <div className="input-group">

                        <label>
                            Permission
                        </label>

                        <select
                            value={permission}
                            onChange={(e) =>
                                setPermission(e.target.value)
                            }
                        >

                            <option value="download">
                                Download
                            </option>

                            <option value="view">
                                View Only
                            </option>

                        </select>

                    </div>


                    <div className="input-group">

                        <label>
                            Expiry Date & Time
                            <span className="optional-text">
                                Optional
                            </span>
                        </label>

                        <input
                            type="datetime-local"
                            value={expiresAt}
                            onChange={(e) =>
                                setExpiresAt(e.target.value)
                            }
                        />

                    </div>


                    <div className="permission-info">

                        <strong>
                            {permission === "download"
                                ? "Download permission"
                                : "View-only permission"}
                        </strong>

                        <p>
                            {permission === "download"
                                ? "The recipient can view and download this file."
                                : "The recipient can view the file but cannot download it."
                            }
                        </p>

                    </div>


                    <button
                        type="submit"
                        className="share-submit-button"
                        disabled={sharing}
                    >
                        {sharing
                            ? "Sharing..."
                            : "Share File"}
                    </button>

                </form>


                <button
                    className="share-back-button"
                    onClick={() =>
                        navigate("/my-files")
                    }
                >
                    ← Back to My Files
                </button>

            </div>

        </div>
    );
}

export default ShareFile;