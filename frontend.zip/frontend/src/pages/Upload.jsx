import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

function Upload() {

    const [file, setFile] = useState(null);
    const [uploading, setUploading] = useState(false);

    const navigate = useNavigate();

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];

        if (selectedFile) {
            setFile(selectedFile);
        }
    };

    const handleUpload = async (e) => {
        e.preventDefault();

        if (!file) {
            alert("Please select a file");
            return;
        }

        try {

            setUploading(true);

            const token = localStorage.getItem("token");

            const formData = new FormData();
            formData.append("file", file);

            await api.post(
                "/files/upload",
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            alert("File uploaded successfully!");

            navigate("/my-files");

        } catch (error) {

            console.log("UPLOAD ERROR:", error);

            alert(
                error.response?.data?.message ||
                "File upload failed"
            );

        } finally {
            setUploading(false);
        }
    };

    return (
        <div className="upload-page">

            <div className="upload-card">

                <div className="upload-icon-large">
                    📤
                </div>

                <h1>Upload File</h1>

                <p className="upload-subtitle">
                    Select a file to add it to your storage
                </p>

                <form onSubmit={handleUpload}>

                    <label className="upload-area">

                        <div className="upload-area-icon">
                            📁
                        </div>

                        <h3>
                            Choose a file
                        </h3>

                        <p>
                            Click here to browse files
                        </p>

                        <input
                            type="file"
                            onChange={handleFileChange}
                        />

                    </label>


                    {file && (

                        <div className="selected-file">

                            <span className="selected-file-icon">
                                📄
                            </span>

                            <div>
                                <strong>
                                    {file.name}
                                </strong>

                                <p>
                                    {(
                                        file.size / 1024
                                    ).toFixed(2)} KB
                                </p>
                            </div>

                        </div>

                    )}


                    <button
                        type="submit"
                        className="upload-button"
                        disabled={uploading}
                    >
                        {uploading
                            ? "Uploading..."
                            : "Upload File"}
                    </button>

                </form>


                <button
                    className="back-button"
                    onClick={() => navigate("/my-files")}
                >
                    ← Back to My Files
                </button>

            </div>

        </div>
    );
}

export default Upload;