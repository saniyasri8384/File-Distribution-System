import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import mammoth from "mammoth";
import api from "../services/api";

function FileViewer() {

    const { fileId } = useParams();
    const navigate = useNavigate();

    const [loading, setLoading] = useState(true);
    const [fileUrl, setFileUrl] = useState(null);
    const [fileType, setFileType] = useState("");
    const [textContent, setTextContent] = useState("");
    const [docxHtml, setDocxHtml] = useState("");

    const fetchFile = async () => {

        try {

            const token = localStorage.getItem("token");

            const response = await api.get(
                `/files/view/${fileId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    responseType: "blob"
                }
            );

            const blob = response.data;

            setFileType(blob.type || "");

            // DOCX files
            if (
                blob.type ===
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            ) {

                const arrayBuffer = await blob.arrayBuffer();

                const result = await mammoth.convertToHtml({
                    arrayBuffer
                });

                setDocxHtml(result.value);

                return;
            }

            // Text files
            if (blob.type.startsWith("text/")) {

                const text = await blob.text();

                setTextContent(text);

                return;
            }

            // PDF and image files
            const url = window.URL.createObjectURL(blob);

            setFileUrl(url);

        } catch (error) {

            console.log("FILE VIEW ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Unable to view file"
            );

            navigate("/shared-files");

        } finally {

            setLoading(false);
        }
    };

    useEffect(() => {

        fetchFile();

        return () => {

            if (fileUrl) {
                window.URL.revokeObjectURL(fileUrl);
            }

        };

    }, [fileId]);

    if (loading) {

        return (
            <div className="page-container">
                <h2>Opening file...</h2>
            </div>
        );
    }

    return (
        <div className="page-container">

            <button
                onClick={() =>
                    navigate("/shared-files")
                }
                style={{
                    background: "transparent",
                    color: "#2563eb",
                    padding: 0,
                    marginBottom: "20px"
                }}
            >
                ← Back to Shared Files
            </button>

            <div
                style={{
                    background: "white",
                    borderRadius: "14px",
                    padding: "25px",
                    minHeight: "70vh",
                    boxShadow:
                        "0 4px 18px rgba(0,0,0,0.06)"
                }}
            >

                {/* DOCX Preview */}

                {docxHtml && (

                    <div
                        style={{
                            maxWidth: "850px",
                            margin: "0 auto",
                            lineHeight: "1.7"
                        }}
                        dangerouslySetInnerHTML={{
                            __html: docxHtml
                        }}
                    />

                )}

                {/* Text Preview */}

                {textContent && (

                    <pre
                        style={{
                            whiteSpace: "pre-wrap",
                            wordBreak: "break-word",
                            fontFamily: "monospace",
                            lineHeight: "1.6"
                        }}
                    >
                        {textContent}
                    </pre>

                )}

                {/* PDF Preview */}

                {fileType === "application/pdf" &&
                    fileUrl && (

                        <iframe
                            src={fileUrl}
                            title="PDF Preview"
                            style={{
                                width: "100%",
                                height: "70vh",
                                border: "none"
                            }}
                        />

                    )}

                {/* Image Preview */}

                {fileType.startsWith("image/") &&
                    fileUrl && (

                        <div
                            style={{
                                textAlign: "center"
                            }}
                        >

                            <img
                                src={fileUrl}
                                alt="File preview"
                                style={{
                                    maxWidth: "100%",
                                    maxHeight: "70vh",
                                    objectFit: "contain"
                                }}
                            />

                        </div>

                    )}

            </div>

        </div>
    );
}

export default FileViewer;