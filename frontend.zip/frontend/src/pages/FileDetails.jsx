import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import api from "../services/api";

function FileDetails() {

    const { fileId } = useParams();
    const navigate = useNavigate();

    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(true);

    const fetchFileDetails = async () => {

        try {

            const token = localStorage.getItem("token");

            const response = await api.get(
                `/files/details/${fileId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            setFile(
                response.data.file ||
                response.data
            );

        } catch (error) {

            console.log("FILE DETAILS ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Failed to load file details"
            );

        } finally {

            setLoading(false);
        }
    };

    useEffect(() => {
        fetchFileDetails();
    }, [fileId]);


    const formatBytes = (bytes) => {

        if (!bytes || bytes === 0) {
            return "0 Bytes";
        }

        const units = [
            "Bytes",
            "KB",
            "MB",
            "GB"
        ];

        const index = Math.floor(
            Math.log(bytes) / Math.log(1024)
        );

        return (
            parseFloat(
                (bytes / Math.pow(1024, index)).toFixed(2)
            ) +
            " " +
            units[index]
        );
    };


    const getFileIcon = (mimeType) => {

        if (mimeType === "application/pdf") {
            return "📕";
        }

        if (mimeType?.startsWith("image/")) {
            return "🖼️";
        }

        if (mimeType?.startsWith("text/")) {
            return "📄";
        }

        if (
            mimeType?.includes("word") ||
            mimeType?.includes("document")
        ) {
            return "📝";
        }

        if (
            mimeType?.includes("zip") ||
            mimeType?.includes("compressed")
        ) {
            return "🗜️";
        }

        return "📁";
    };


    if (loading) {

        return (
            <div
                style={{
                    maxWidth: "1000px",
                    margin: "0 auto",
                    padding: "40px"
                }}
            >
                <h2>Loading file details...</h2>
            </div>
        );
    }


    if (!file) {

        return (
            <div
                style={{
                    maxWidth: "700px",
                    margin: "40px auto",
                    padding: "30px",
                    background: "white",
                    borderRadius: "14px",
                    textAlign: "center",
                    boxShadow:
                        "0 4px 18px rgba(0,0,0,0.06)"
                }}
            >

                <div
                    style={{
                        fontSize: "50px",
                        marginBottom: "15px"
                    }}
                >
                    📂
                </div>

                <h2>File not found</h2>

                <p style={{ color: "#64748b" }}>
                    The requested file could not be found.
                </p>

                <button
                    onClick={() => navigate("/my-files")}
                    style={{
                        marginTop: "15px",
                        background: "#2563eb"
                    }}
                >
                    ← Back to My Files
                </button>

            </div>
        );
    }


    return (
        <div
            style={{
                maxWidth: "1000px",
                margin: "0 auto",
                padding: "40px 30px"
            }}
        >

            {/* Header */}

            <div
                style={{
                    marginBottom: "25px"
                }}
            >

                <button
                    onClick={() => navigate("/my-files")}
                    style={{
                        background: "transparent",
                        color: "#2563eb",
                        padding: "0",
                        marginBottom: "15px",
                        fontWeight: "600"
                    }}
                >
                    ← Back to My Files
                </button>

                <h1
                    style={{
                        margin: "0 0 6px",
                        fontSize: "32px"
                    }}
                >
                    File Details
                </h1>

                <p
                    style={{
                        margin: 0,
                        color: "#64748b"
                    }}
                >
                    View information about this file
                </p>

            </div>


            {/* Main Card */}

            <div
                style={{
                    background: "white",
                    borderRadius: "16px",
                    padding: "30px",
                    boxShadow:
                        "0 4px 20px rgba(0,0,0,0.06)"
                }}
            >

                {/* File Header */}

                <div
                    style={{
                        display: "flex",
                        alignItems: "center",
                        gap: "18px",
                        paddingBottom: "25px",
                        borderBottom: "1px solid #e5e7eb",
                        marginBottom: "25px"
                    }}
                >

                    <div
                        style={{
                            width: "65px",
                            height: "65px",
                            borderRadius: "14px",
                            background: "#eff6ff",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: "32px"
                        }}
                    >
                        {getFileIcon(file.mimeType)}
                    </div>

                    <div>

                        <h2
                            style={{
                                margin: "0 0 5px",
                                fontSize: "22px",
                                wordBreak: "break-word"
                            }}
                        >
                            {file.originalName}
                        </h2>

                        <p
                            style={{
                                margin: 0,
                                color: "#64748b",
                                fontSize: "14px"
                            }}
                        >
                            {file.mimeType || "Unknown file type"}
                        </p>

                    </div>

                </div>


                {/* Details Grid */}

                <div
                    style={{
                        display: "grid",
                        gridTemplateColumns:
                            "repeat(2, minmax(0, 1fr))",
                        gap: "18px"
                    }}
                >

                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            FILE NAME
                        </span>

                        <strong>
                            {file.originalName || "-"}
                        </strong>
                    </div>


                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            FILE TYPE
                        </span>

                        <strong>
                            {file.mimeType || "-"}
                        </strong>
                    </div>


                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            FILE SIZE
                        </span>

                        <strong>
                            {formatBytes(file.size)}
                        </strong>
                    </div>


                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            UPLOADED ON
                        </span>

                        <strong>
                            {file.createdAt
                                ? new Date(
                                    file.createdAt
                                ).toLocaleString()
                                : "-"}
                        </strong>
                    </div>


                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            UPDATED ON
                        </span>

                        <strong>
                            {file.updatedAt
                                ? new Date(
                                    file.updatedAt
                                ).toLocaleString()
                                : "-"}
                        </strong>
                    </div>


                    <div style={{
                        background: "#f8fafc",
                        padding: "18px",
                        borderRadius: "10px"
                    }}>
                        <span
                            style={{
                                display: "block",
                                color: "#64748b",
                                fontSize: "12px",
                                marginBottom: "6px"
                            }}
                        >
                            FILE ID
                        </span>

                        <strong
                            style={{
                                fontSize: "13px",
                                wordBreak: "break-all"
                            }}
                        >
                            {file._id || "-"}
                        </strong>
                    </div>

                </div>

            </div>

        </div>
    );
}

export default FileDetails;