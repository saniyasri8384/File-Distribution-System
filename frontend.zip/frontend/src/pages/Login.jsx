import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";

function Login() {

    const { login } = useAuth();

    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);

    const navigate = useNavigate();

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            setLoading(true);

            const response = await api.post("/auth/login", {
                email,
                password
            });

            console.log("LOGIN SUCCESS:", response.data);

            login(response.data.token);

            navigate("/dashboard");

        } catch (error) {

            console.log("LOGIN ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Login failed"
            );

        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="login-page">

            {/* Animated background shapes */}
            <div className="background-shape shape-one"></div>
            <div className="background-shape shape-two"></div>
            <div className="background-shape shape-three"></div>

            <div className="login-card">

                <div className="login-logo">
                    📁
                </div>

                <h1>Welcome Back</h1>

                <p className="login-subtitle">
                    Sign in to manage and share your files
                </p>

                <form onSubmit={handleLogin}>

                    <div className="input-group">
                        <label>Email</label>

                        <input
                            type="email"
                            placeholder="Enter your email"
                            value={email}
                            onChange={(e) =>
                                setEmail(e.target.value)
                            }
                            required
                        />
                    </div>

                    <div className="input-group">
                        <label>Password</label>

                        <div className="password-input-wrapper">

    <input
        type={showPassword ? "text" : "password"}
        placeholder="Enter your password"
        value={password}
        onChange={(e) =>
            setPassword(e.target.value)
        }
        required
    />

    <button
        type="button"
        className="password-toggle"
        onClick={() =>
            setShowPassword(!showPassword)
        }
    >
        {showPassword ? "Hide" : "Show"}
    </button>

</div>
                    </div>

                    <button
                        type="submit"
                        className="login-button"
                        disabled={loading}
                    >
                        {loading ? "Signing in..." : "Sign In"}
                    </button>

                </form>

                <p className="register-text">
                    Don't have an account?{" "}

                    <Link to="/register">
                        Create an account
                    </Link>
                </p>

            </div>

        </div>
    );
}

export default Login;