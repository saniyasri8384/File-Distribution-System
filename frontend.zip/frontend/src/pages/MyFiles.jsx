import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../services/api";

function MyFiles() {

    const [files, setFiles] = useState([]);
    const [loading, setLoading] = useState(true);

    const [searchName, setSearchName] = useState("");
    const [mimeType, setMimeType] = useState("");

    const navigate = useNavigate();

    const fetchFiles = async () => {
        try {
            const token = localStorage.getItem("token");

            const response = await api.get("/files/my-files", {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            setFiles(response.data.files || []);

        } catch (error) {
            console.log("MY FILES ERROR:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchFiles();
    }, []);

    const handleSearch = async () => {
        try {
            setLoading(true);

            const token = localStorage.getItem("token");

            const params = {};

            if (searchName.trim() !== "") {
                params.name = searchName;
            }

            if (mimeType !== "") {
                params.mimeType = mimeType;
            }

            if (Object.keys(params).length === 0) {
                await fetchFiles();
                return;
            }

            const response = await api.get("/files/search", {
                params: params,
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            setFiles(response.data.files || []);

        } catch (error) {
            console.log("SEARCH ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Search failed"
            );

        } finally {
            setLoading(false);
        }
    };

    const handleClearSearch = () => {
        setSearchName("");
        setMimeType("");
        fetchFiles();
    };

    const handleDownload = async (fileId, fileName) => {
        try {
            const token = localStorage.getItem("token");

            const response = await api.get(
                `/files/download/${fileId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    responseType: "blob"
                }
            );

            const url = window.URL.createObjectURL(
                new Blob([response.data])
            );

            const link = document.createElement("a");

            link.href = url;
            link.download = fileName;

            document.body.appendChild(link);
            link.click();
            link.remove();

            window.URL.revokeObjectURL(url);

        } catch (error) {
            console.log("DOWNLOAD ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Download failed"
            );
        }
    };

    const handleDelete = async (fileId) => {

        const confirmDelete = window.confirm(
            "Are you sure you want to delete this file?"
        );

        if (!confirmDelete) {
            return;
        }

        try {
            const token = localStorage.getItem("token");

            await api.delete(
                `/files/delete/${fileId}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            alert("File deleted successfully!");

            fetchFiles();

        } catch (error) {
            console.log("DELETE ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Delete failed"
            );
        }
    };

    const handleShare = (fileId) => {
        navigate(`/share/${fileId}`);
    };

    const handleDetails = (fileId) => {
        navigate(`/file-details/${fileId}`);
    };

    if (loading) {
        return (
            <div className="page-container">
                <h2>Loading files...</h2>
            </div>
        );
    }

    return (
        <div className="page-container">

            <div className="page-header">

                <div>
                    <h1>My Files</h1>

                    <p>
                        Manage, download and share your files
                    </p>
                </div>

                <button
                    className="primary-button"
                    onClick={() => navigate("/upload")}
                >
                    + Upload File
                </button>

            </div>

            <div className="file-search-box">

                <input
                    type="text"
                    placeholder="Search by file name..."
                    value={searchName}
                    onChange={(e) =>
                        setSearchName(e.target.value)
                    }
                    onKeyDown={(e) => {
                        if (e.key === "Enter") {
                            handleSearch();
                        }
                    }}
                />

                <select
                    value={mimeType}
                    onChange={(e) =>
                        setMimeType(e.target.value)
                    }
                >
                    <option value="">
                        All File Types
                    </option>

                    <option value="application/pdf">
                        PDF
                    </option>

                    <option value="image/jpeg">
                        JPG
                    </option>

                    <option value="image/png">
                        PNG
                    </option>

                    <option value="text/plain">
                        Text
                    </option>
                </select>

                <button
                    className="search-button"
                    onClick={handleSearch}
                >
                    Search
                </button>

                <button
                    className="clear-button"
                    onClick={handleClearSearch}
                >
                    Clear
                </button>

            </div>

            {files.length === 0 ? (

                <div className="empty-files-card">

                    <div className="empty-files-icon">
                        📂
                    </div>

                    <h2>No files found</h2>

                    <p>
                        Upload a file to start managing your documents.
                    </p>

                    <button
                        className="primary-button"
                        onClick={() => navigate("/upload")}
                    >
                        Upload File
                    </button>

                </div>

            ) : (

                <div className="files-table-card">

                    <div className="files-count">
                        {files.length} file
                        {files.length !== 1 ? "s" : ""}
                    </div>

                    <div className="files-table-wrapper">

                        <table className="modern-files-table">

                            <thead>
                                <tr>
                                    <th>File</th>
                                    <th>Type</th>
                                    <th>Size</th>
                                    <th>Uploaded</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>

                            <tbody>

                                {files.map((file) => (

                                    <tr key={file._id}>

                                        <td>
                                            <strong>
                                                {file.originalName}
                                            </strong>
                                        </td>

                                        <td>
                                            {file.mimeType || "-"}
                                        </td>

                                        <td>
                                            {file.size} bytes
                                        </td>

                                        <td>
                                            {new Date(
                                                file.createdAt
                                            ).toLocaleDateString()}
                                        </td>

                                        <td>

                                            <button
                                                onClick={() =>
                                                    handleDownload(
                                                        file._id,
                                                        file.originalName
                                                    )
                                                }
                                            >
                                                Download
                                            </button>

                                            {" "}

                                            <button
                                                onClick={() =>
                                                    handleShare(file._id)
                                                }
                                            >
                                                Share
                                            </button>

                                            {" "}

                                            <button
                                                onClick={() =>
                                                    handleDetails(file._id)
                                                }
                                            >
                                                Details
                                            </button>

                                            {" "}

                                            <button
                                                onClick={() =>
                                                    handleDelete(file._id)
                                                }
                                            >
                                                Delete
                                            </button>

                                        </td>

                                    </tr>

                                ))}

                            </tbody>

                        </table>

                    </div>

                </div>

            )}

        </div>
    );
}

export default MyFiles;