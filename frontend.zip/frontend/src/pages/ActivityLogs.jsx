import { useEffect, useState } from "react";
import api from "../services/api";

function ActivityLogs() {

    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchLogs = async () => {
        try {
            const token = localStorage.getItem("token");

            const response = await api.get(
                "/files/activity-logs",
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            setLogs(response.data.logs || []);

        } catch (error) {
            console.log("ACTIVITY LOGS ERROR:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchLogs();
    }, []);

    const getActionStyle = (action) => {

        switch (action) {

            case "UPLOAD":
                return {
                    background: "#dcfce7",
                    color: "#15803d"
                };

            case "DOWNLOAD":
                return {
                    background: "#dbeafe",
                    color: "#1d4ed8"
                };

            case "SHARE":
                return {
                    background: "#ede9fe",
                    color: "#6d28d9"
                };

            case "DELETE":
                return {
                    background: "#fee2e2",
                    color: "#b91c1c"
                };

            case "CHANGE_PERMISSION":
                return {
                    background: "#fef3c7",
                    color: "#92400e"
                };

            case "REVOKE_SHARE":
                return {
                    background: "#fce7f3",
                    color: "#be185d"
                };

            default:
                return {
                    background: "#f1f5f9",
                    color: "#475569"
                };
        }
    };

    const getActionIcon = (action) => {

        switch (action) {

            case "UPLOAD":
                return "⬆️";

            case "DOWNLOAD":
                return "⬇️";

            case "SHARE":
                return "🤝";

            case "DELETE":
                return "🗑️";

            case "CHANGE_PERMISSION":
                return "🔐";

            case "REVOKE_SHARE":
                return "🚫";

            default:
                return "📝";
        }
    };

    if (loading) {
        return (
            <div className="page-container">
                <h2>Loading activity logs...</h2>
            </div>
        );
    }

    return (
        <div
            className="page-container"
            style={{
                maxWidth: "1200px",
                margin: "0 auto",
                padding: "35px 30px"
            }}
        >

            {/* Header */}

            <div
                style={{
                    marginBottom: "25px"
                }}
            >
                <h1
                    style={{
                        margin: "0 0 6px",
                        fontSize: "32px"
                    }}
                >
                    Activity Logs
                </h1>

                <p
                    style={{
                        margin: 0,
                        color: "#64748b",
                        fontSize: "16px"
                    }}
                >
                    Track your file activity and sharing actions
                </p>
            </div>


            {/* Empty state */}

            {logs.length === 0 ? (

                <div
                    style={{
                        background: "white",
                        borderRadius: "14px",
                        padding: "60px 25px",
                        textAlign: "center",
                        boxShadow:
                            "0 4px 18px rgba(0,0,0,0.06)"
                    }}
                >

                    <div
                        style={{
                            fontSize: "50px",
                            marginBottom: "15px"
                        }}
                    >
                        📝
                    </div>

                    <h2>No activity found</h2>

                    <p
                        style={{
                            color: "#64748b"
                        }}
                    >
                        Your file activity will appear here.
                    </p>

                </div>

            ) : (

                <div
                    style={{
                        background: "white",
                        borderRadius: "14px",
                        padding: "24px",
                        boxShadow:
                            "0 4px 18px rgba(0,0,0,0.06)"
                    }}
                >

                    {/* Count */}

                    <div
                        style={{
                            color: "#64748b",
                            fontSize: "14px",
                            fontWeight: "600",
                            marginBottom: "10px"
                        }}
                    >
                        {logs.length} activit
                        {logs.length === 1 ? "y" : "ies"}
                    </div>


                    {/* Logs */}

                    <div>

                        {logs.map((log) => {

                            const actionStyle =
                                getActionStyle(log.action);

                            return (

                                <div
                                    key={log._id}
                                    style={{
                                        display: "flex",
                                        alignItems: "flex-start",
                                        gap: "16px",
                                        padding: "18px 4px",
                                        borderBottom:
                                            "1px solid #e5e7eb"
                                    }}
                                >

                                    {/* Icon */}

                                    <div
                                        style={{
                                            width: "46px",
                                            height: "46px",
                                            minWidth: "46px",
                                            borderRadius: "11px",
                                            display: "flex",
                                            alignItems: "center",
                                            justifyContent: "center",
                                            background:
                                                actionStyle.background,
                                            fontSize: "20px"
                                        }}
                                    >
                                        {getActionIcon(log.action)}
                                    </div>


                                    {/* Content */}

                                    <div
                                        style={{
                                            flex: 1,
                                            minWidth: 0
                                        }}
                                    >

                                        {/* Top row */}

                                        <div
                                            style={{
                                                display: "flex",
                                                justifyContent:
                                                    "space-between",
                                                alignItems: "center",
                                                gap: "15px",
                                                marginBottom: "7px",
                                                flexWrap: "wrap"
                                            }}
                                        >

                                            <span
                                                style={{
                                                    display:
                                                        "inline-block",
                                                    padding: "5px 10px",
                                                    borderRadius: "20px",
                                                    background:
                                                        actionStyle.background,
                                                    color:
                                                        actionStyle.color,
                                                    fontSize: "11px",
                                                    fontWeight: "700"
                                                }}
                                            >
                                                {log.action.replace(
                                                    /_/g,
                                                    " "
                                                )}
                                            </span>

                                            <span
                                                style={{
                                                    color: "#94a3b8",
                                                    fontSize: "12px"
                                                }}
                                            >
                                                {new Date(
                                                    log.createdAt
                                                ).toLocaleString()}
                                            </span>

                                        </div>


                                        {/* File name */}

                                        <strong
                                            style={{
                                                display: "block",
                                                fontSize: "15px",
                                                color: "#1f2937"
                                            }}
                                        >
                                            {log.file?.originalName ||
                                                "No file associated"}
                                        </strong>


                                        {/* Details */}

                                        {log.details && (
                                            <p
                                                style={{
                                                    margin: "5px 0 0",
                                                    color: "#64748b",
                                                    fontSize: "13px"
                                                }}
                                            >
                                                {log.details}
                                            </p>
                                        )}

                                    </div>

                                </div>
                            );
                        })}

                    </div>

                </div>
            )}

        </div>
    );
}

export default ActivityLogs;