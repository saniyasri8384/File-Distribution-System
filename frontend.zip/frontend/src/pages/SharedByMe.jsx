import { useEffect, useState } from "react";
import api from "../services/api";

function SharedByMe() {

    const [shares, setShares] = useState([]);
    const [loading, setLoading] = useState(true);

    const fetchShares = async () => {
        try {
            const token = localStorage.getItem("token");

            const response = await api.get(
                "/files/shared-by-me",
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            setShares(
                response.data.shares ||
                response.data.files ||
                []
            );

        } catch (error) {

            console.log("SHARED BY ME ERROR:", error);

        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchShares();
    }, []);

    const handlePermissionChange = async (
        shareId,
        newPermission
    ) => {

        try {

            const token = localStorage.getItem("token");

            await api.patch(
                `/files/change-permission/${shareId}`,
                {
                    permission: newPermission
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            );

            alert("Permission changed successfully!");

            fetchShares();

        } catch (error) {

            console.log("PERMISSION ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Failed to change permission"
            );
        }
    };

    const handleRevoke = async (shareId) => {

        const confirmRevoke = window.confirm(
            "Are you sure you want to revoke this share?"
        );

        if (!confirmRevoke) {
            return;
        }

        try {

            const token = localStorage.getItem("token");
const response = await api.delete(
    `/files/revoke-share/${shareId}`,
    {
        headers: {
            Authorization: `Bearer ${token}`
        }
    }
);

console.log("REVOKE RESPONSE:", response.data);

alert("Share revoked successfully!");

await fetchShares();

        } catch (error) {

            console.log("REVOKE ERROR:", error);

            alert(
                error.response?.data?.message ||
                "Failed to revoke share"
            );
        }
    };

    const getFileIcon = (mimeType) => {

        if (mimeType === "application/pdf") {
            return "📕";
        }

        if (mimeType?.startsWith("image/")) {
            return "🖼️";
        }

        if (mimeType?.startsWith("text/")) {
            return "📄";
        }

        return "📁";
    };

    if (loading) {
        return (
            <div className="page-container">
                <h2>Loading shared files...</h2>
            </div>
        );
    }

    return (
        <div className="page-container">

            <div className="page-header">

                <div>
                    <h1>Shared By Me</h1>

                    <p>
                        Manage files you have shared with other users
                    </p>
                </div>

            </div>


            {shares.length === 0 ? (

                <div className="empty-files-card">

                    <div className="empty-files-icon">
                        📤
                    </div>

                    <h2>No shared files</h2>

                    <p>
                        You have not shared any files yet.
                    </p>

                </div>

            ) : (

                <div className="files-table-card">

                    <div className="files-count">
                        {shares.length} share
                        {shares.length !== 1 ? "s" : ""}
                    </div>

                    <div className="files-table-wrapper">

                        <table className="modern-files-table">

                            <thead>
                                <tr>
                                    <th>File</th>
                                    <th>Shared With</th>
                                    <th>Permission</th>
                                    <th>Expiry</th>
                                    <th>Action</th>
                                </tr>
                            </thead>

                            <tbody>

                                {shares.map((share) => {

                                    const file = share.file;
                                    const user = share.sharedWith;

                                    return (
                                        <tr key={share._id}>

                                            <td>

                                                <div className="file-name-cell">

                                                    <div className="file-type-icon">
                                                        {getFileIcon(
                                                            file?.mimeType
                                                        )}
                                                    </div>

                                                    <div>

                                                        <strong>
                                                            {file?.originalName ||
                                                                "Unknown file"}
                                                        </strong>

                                                        <span>
                                                            {file?.mimeType ||
                                                                "-"}
                                                        </span>

                                                    </div>

                                                </div>

                                            </td>


                                            <td>
                                                {user?.email ||
                                                    user?.name ||
                                                    "Unknown user"}
                                            </td>


                                            <td>

                                                <select
                                                    className="permission-select"
                                                    value={share.permission}
                                                    onChange={(e) =>
                                                        handlePermissionChange(
                                                            share._id,
                                                            e.target.value
                                                        )
                                                    }
                                                >

                                                    <option value="download">
                                                        Download
                                                    </option>

                                                    <option value="view">
                                                        View
                                                    </option>

                                                </select>

                                            </td>


                                            <td>
                                                {share.expiresAt
                                                    ? new Date(
                                                        share.expiresAt
                                                    ).toLocaleString()
                                                    : "No expiry"}
                                            </td>


                                            <td>

                                                <button
                                                    className="action-button delete"
                                                    onClick={() =>
                                                        handleRevoke(
                                                            share._id
                                                        )
                                                    }
                                                >
                                                    Revoke
                                                </button>

                                            </td>

                                        </tr>
                                    );

                                })}

                            </tbody>

                        </table>

                    </div>

                </div>

            )}

        </div>
    );
}

export default SharedByMe;