import {
    BrowserRouter,
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import { AuthProvider } from "./context/AuthContext";

import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import MyFiles from "./pages/MyFiles";
import Upload from "./pages/Upload";
import ShareFile from "./pages/ShareFile";
import SharedFiles from "./pages/SharedFiles";
import SharedByMe from "./pages/SharedByMe";
import ActivityLogs from "./pages/ActivityLogs";
import FileDetails from "./pages/FileDetails";
import FileViewer from "./pages/FileViewer";

import Navbar from "./components/Navbar";
import ProtectedRoute from "./components/ProtectedRoute";

function App() {

    return (
        <AuthProvider>

            <BrowserRouter>

                <Navbar />

                <Routes>

                    {/* Public Routes */}

                    <Route
                        path="/"
                        element={<Navigate to="/login" />}
                    />

                    <Route
                        path="/login"
                        element={<Login />}
                    />

                    <Route
                        path="/register"
                        element={<Register />}
                    />


                    {/* Protected Routes */}

                    <Route
                        path="/dashboard"
                        element={
                            <ProtectedRoute>
                                <Dashboard />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/my-files"
                        element={
                            <ProtectedRoute>
                                <MyFiles />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/upload"
                        element={
                            <ProtectedRoute>
                                <Upload />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/share/:fileId"
                        element={
                            <ProtectedRoute>
                                <ShareFile />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/shared-files"
                        element={
                            <ProtectedRoute>
                                <SharedFiles />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/shared-by-me"
                        element={
                            <ProtectedRoute>
                                <SharedByMe />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/activity-logs"
                        element={
                            <ProtectedRoute>
                                <ActivityLogs />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/file-details/:fileId"
                        element={
                            <ProtectedRoute>
                                <FileDetails />
                            </ProtectedRoute>
                        }
                    />

                    <Route
    path="/view/:fileId"
    element={
        <ProtectedRoute>
            <FileViewer />
        </ProtectedRoute>
    }
/>

                </Routes>

            </BrowserRouter>

        </AuthProvider>
    );
}

export default App;