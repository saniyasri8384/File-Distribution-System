import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Navbar() {

    const location = useLocation();
    const navigate = useNavigate();

    const { isAuthenticated, logout } = useAuth();

    const handleLogout = () => {
        logout();
        navigate("/login");
    };

    // Login/Register page par Navbar nahi dikhana
    if (
        location.pathname === "/login" ||
        location.pathname === "/register"
    ) {
        return null;
    }

    // User logged in nahi hai
    if (!isAuthenticated) {
        return null;
    }

    return (
        <nav>

            <h2>File Distribution System</h2>

            <div>

                <Link to="/dashboard">
                    Dashboard
                </Link>

                {" | "}

                <Link to="/my-files">
                    My Files
                </Link>

                {" | "}

                <Link to="/upload">
                    Upload File
                </Link>

                {" | "}

                <Link to="/shared-files">
                    Shared Files
                </Link>

                {" | "}

                <Link to="/shared-by-me">
                    Shared By Me
                </Link>

                {" | "}

                <Link to="/activity-logs">
                    Activity Logs
                </Link>

                {" | "}

                <button onClick={handleLogout}>
                    Logout
                </button>

            </div>

        </nav>
    );
}

export default Navbar;